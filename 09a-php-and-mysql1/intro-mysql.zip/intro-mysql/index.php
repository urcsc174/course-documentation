<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Intro to MySql</title>
	<style>
		body { 
			display: grid;
			height: 100vh;
			margin: 0;
			place-items: center;

			background-color: lightyellow;
			font-family: 'Helvetica', Arial, sans-serif; 
			color: #333333;
		}
		main {
			text-align: center;
		}
		h1, p, ul{ 
			line-height: 1.5em;
			margin: 0; 
		}
		footer {
			position: fixed;
			width: 100%;
			bottom: 0;
			display: flex;
			justify-content: space-between;
			align-items: flex-end;	
		}
		.weak {
			left: 0;
			padding: 0 0 50px 50px;
		}
		.terminal {
			right: 0;
			padding: 0 50px 50px 0;
			background-color: lightyellow;
		}
		a[target="_blank"]::after {
			content: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAQElEQVR42qXKwQkAIAxDUUdxtO6/RBQkQZvSi8I/pL4BoGw/XPkh4XigPmsUgh0626AjRsgxHTkUThsG2T/sIlzdTsp52kSS1wAAAABJRU5ErkJggg==);
			margin: 0 3px 0 5px;
		}
	</style>
</head>
<body>
	<main>
		<img src="yin-yang.png" alt="Yin-Yang">
		<h1>Hello MySQL!</h1>
	</main>
	<footer>
		<div class="weak">
			Server name: <samp><?php echo $_SERVER['SERVER_NAME']; ?></samp><br>
			Document root: <samp><?php echo $_SERVER['DOCUMENT_ROOT']; ?></samp>
		</div>
		<nav class="terminal">
			<ul>
				<li><a href="serverinfo.php">Server Info</a></li>
				<li><a href="db-tester.php">DB Tester</a></li>
				<li><a href="phpinfo.php" target="_blank">PHP Info</a></li>
				<li><a href="/phpMyAdmin" target="_blank">phpMyAdmin</a></li>
				<li><a href="testmysql.php" target="_blank">DB Connection Tester (standalone)</a></li>
			</ul>
		</nav>
	</footer>
</body>
</html>