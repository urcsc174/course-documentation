<?php
$mysqli = new mysqli('localhost', 'root', 'root', '');

if ($mysqli->connect_error) {
    die('Connect Error (' . $mysqli->connect_errno . ') '
            . $mysqli->connect_error);
}
echo '<div>Connection OK '. $mysqli->host_info.'</div>';
echo '<div>Server '.$mysqli->server_info.'</div>';
$mysqli->close();
?>