<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Bears</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/styles.css">
	<link href="https://fonts.googleapis.com/css?family=Love+Ya+Like+A+Sister|Open+Sans" rel="stylesheet">
</head>
<body>

<header>
	<div class="container">
		<div class="primary">
			<!-- Primary Optical Area -->
			<a href="index.html"><img src="images/bear-logo.png" alt="Bear logo"></a>
		</div>
		<div class="big-message">
			<a href="index.html"><h1>Bears!</h1></a>
		</div>
		<div class="strong">
			<!-- Strong Follow Area -->
			<div class="excited">Thanks!</div>
		</div>
	</div><!-- .container -->
</header>

<main>
	<div class="container">

		<div class="too-wide2">

			<p>Thank you for subscribing.  You will start receiving the Bear Newsletter at: <strong><?php echo $_POST['email']; ?></strong>.</p>
			
			<p>You may unsubscribe at anytime by clicking the link in the email to do so.</p>

			<p>Enjoy, and remember to keep a safe distance!</p>

			<p>Now <a href="bears.html">Run away!</a></p>

		</div>

	</div><!-- .container -->
</main>

</body>
</html>