<?php
	$dbhost = "localhost";
	$dbuser = "";
	$dbpass = "";
	$dbname = "";
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
?>